package com.capgemini.bookstore.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.bookstore.beans.Customer;
import com.capgemini.bookstore.service.IBookstoreCustomerServiceImpl;

@RestController
@CrossOrigin("http://localhost:4200")
public class BookstoreCommonController {
	
	@Autowired
	IBookstoreCustomerServiceImpl customerServiceImpl;
	
	@PostMapping
	public void saveCustomer(@RequestBody() Customer cust)
	{
		customerServiceImpl.saveCustomer(cust);
	}
	
	@GetMapping("/all")
	public Iterable<Customer> getCustomer()
	{
		return customerServiceImpl.getCustomer();
	}
}
