package com.capgemini.bookstore.service;

import org.springframework.stereotype.Service;

import com.capgemini.bookstore.beans.Customer;

@Service
public interface IBookstoreCustomerService {
	
	public Customer saveCustomer(Customer cust);
	public Iterable<Customer> getCustomer();

}
