package com.capgemini.bookstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.bookstore.beans.Customer;
import com.capgemini.bookstore.dao.IBookstoreCustomerDAO;

@Service
public class IBookstoreCustomerServiceImpl implements IBookstoreCustomerService {

	@Autowired
	IBookstoreCustomerDAO customerdao;
	
	@Override
	@Transactional
	public Customer saveCustomer(Customer cust) {
		// TODO Auto-generated method stub
		return customerdao.save(cust);
	}

	@Override
	@Transactional
	public Iterable<Customer> getCustomer() {
		// TODO Auto-generated method stub
		return customerdao.findAll();
	}

}
