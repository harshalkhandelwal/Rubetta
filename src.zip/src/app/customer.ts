export class Customer
{
    customerid:number;
    address:string;
    city:string;
    country:string;
    date:Date;
    email:string;
    fullname:string;
    mobilenumber:number;
    password:string;
    zipcode:number;
}