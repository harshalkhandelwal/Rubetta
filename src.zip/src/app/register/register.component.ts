import { Component, OnInit } from '@angular/core';
import { RegisterService } from '../register.service';
import { Customer } from '../customer';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  title='BookStore: Register as Customer'

  cust:Customer[];
  c:Customer = new Customer(); 
  public constructor(private registerService:RegisterService) 
  {

   }

  ngOnInit() {
  }

  public saveCustomer():void
  {
    this.registerService.saveCustomer(this.c).subscribe();
  }



}
