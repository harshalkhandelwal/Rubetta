import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable()
export class RegisterService {

  public constructor(private httpClient:HttpClient) 
  {

   }
   public saveCustomer(cust):any
   {
     return this.httpClient.post('http://localhost:8088',cust);

   }
}
